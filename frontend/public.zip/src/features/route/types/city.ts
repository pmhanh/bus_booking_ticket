export type City = {
  id: number;
  name: string;
  slug: string;
  country: string;
};
